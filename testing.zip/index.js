// let ssbg = document.getElementById("slideshow_pic");
// let sstxt = document.getElementById("slide_textarea"); 
// let sstxtHead = document.getElementById("slide_textHead"); 
// let sstxtCont = document.getElementById("slide_textContent"); 
// let dotContainer = document.getElementById("dotContainer");

// var images = ["assets/consulting_1.png", "assets/consulting_2.png", "assets/consulting_3.png"];
// var textHead = ["Operations Management", "Financial", "Business Operations"]; 
// var textContent = [
//     ["- Business Process Improvement", "- Online Digital Payments", "- Re-Insurance", "- Model Analysis", "- Insurance Exposure"],
//     ["- Improve Production Efficiency", "- Manage Quality Controls", "- Compliance, Risk, and Legal Sector"],
//     ["- Business Process Improvement", "- Online Digital Payments", "- Re-Insurance", "- Model Analysis and Development", "- Insurance Exposure and Data Loss Reporting"]
// ]; 

// var currentIndex = 0;

// function updateBackground() {
//     ssbg.style.transition = "opacity 0.33s ease-in-out"; // Adding transition
//     ssbg.style.opacity = 0; // Start with opacity 0
//     sstxtHead.innerHTML = `${textHead[currentIndex]}`; 
//     sstxtCont.innerHTML = "";

//     // Create and append <p> elements for each entry in textContent array
//     textContent[currentIndex].forEach(content => {
//         const paragraph = document.createElement("div");
//         paragraph.className = "agile_p pt-2";
//         paragraph.textContent = content;
//         sstxtCont.appendChild(paragraph);
//     });

//     // Update dots
//     const dots = Array.from(dotContainer.children);
//     dots.forEach((dot, index) => {
//         if (index === currentIndex) {
//             dot.classList.add("active");
//         } else {
//             dot.classList.remove("active");
//         }
//     });
  
//     setTimeout(() => {
//         ssbg.style.background = `url(${images[currentIndex]})`;
//         ssbg.style.width = "100%";
//         ssbg.style.height = "300px";
//         ssbg.style.marginRight = "1.5rem"
//         ssbg.style.backgroundPosition = "center";
//         ssbg.style.backgroundSize = "cover";
//         ssbg.style.backgroundRepeat = "no-repeat";
//         ssbg.style.borderRadius = "5px";
//         ssbg.style.boxShadow = "0 0 5px rgba(0, 0, 0, 0.4)";
//         ssbg.style.opacity = 1; // Set opacity to 1 after updating background
//     }, 140); // Wait for 0.33 seconds (330 milliseconds)
// }

// // Function to generate dots
// function generateDots() {
//     for (let i = 0; i < images.length; i++) {
//         const dot = document.createElement("p");
//         dot.className = "dot";
//         dot.addEventListener("click", () => {
//             currentIndex = i;
//             updateBackground();
//         });
//         dotContainer.appendChild(dot);
//     }
// }

// document.getElementById("nextBtn").addEventListener("click", function () {
//     currentIndex++;
//     if (currentIndex >= images.length) {
//         currentIndex = 0;
//     }
//     updateBackground();
// });

// document.getElementById("prevBtn").addEventListener("click", function () {
//     currentIndex--;
//     if (currentIndex < 0) {
//         currentIndex = images.length - 1;
//     }
//     updateBackground();
// });



// generateDots();
// updateBackground();

let ssbg = document.getElementById("slideshow_pic");
let sstxt = document.getElementById("slide_textarea");
let sstxtHead = document.getElementById("slide_textHead");
let sstxtCont = document.getElementById("slide_textContent");
let dotContainer = document.getElementById("dotContainer");

var images = ["assets/consulting_1.png", "assets/consulting_2.png", "assets/consulting_3.png"];
var textHead = ["Operations Management", "Financial", "Business Operations"];
var textContent = [
    ["- Business Process Improvement", "- Online Digital Payments", "- Re-Insurance", "- Model Analysis", "- Insurance Exposure"],
    ["- Improve Production Efficiency", "- Manage Quality Controls", "- Compliance, Risk, and Legal Sector"],
    ["- Business Process Improvement", "- Online Digital Payments", "- Re-Insurance", "- Model Analysis and Development", "- Insurance Exposure and Data Loss Reporting"]
];

var currentIndex = 0;

function updateBackground() {
    ssbg.style.transition = "opacity 0.33s ease-in-out"; // Adding transition
    ssbg.style.opacity = 0; // Start with opacity 0
    sstxtHead.innerHTML = `${textHead[currentIndex]}`;
    sstxtCont.innerHTML = "";

    // Create and append <p> elements for each entry in textContent array
    textContent[currentIndex].forEach(content => {
        const paragraph = document.createElement("div");
        paragraph.className = "lookInJs"; 
        paragraph.className = "agile_p pt-2";
        paragraph.textContent = content;
        sstxtCont.appendChild(paragraph);
    });

    // Update dots
    const dots = Array.from(dotContainer.children);
    dots.forEach((dot, index) => {
        if (index === currentIndex) {
            dot.classList.add("active");
        } else {
            dot.classList.remove("active");
        }
    });

    setTimeout(() => {
        ssbg.style.background = `url(${images[currentIndex]})`;
        ssbg.style.width = "100%";
        ssbg.style.height = "350px";
        ssbg.style.marginRight = "1.5rem"
        ssbg.style.backgroundPosition = "center";
        ssbg.style.backgroundSize = "cover";
        ssbg.style.backgroundRepeat = "no-repeat";
        ssbg.style.borderRadius = "5px";
        ssbg.style.boxShadow = "0 0 5px rgba(0, 0, 0, 0.4)";
        ssbg.style.opacity = 1; // Set opacity to 1 after updating background
    }, 140); // Wait for 0.33 seconds (330 milliseconds)
}

// Function to generate dots
function generateDots() {
    for (let i = 0; i < images.length; i++) {
        const dot = document.createElement("p");
        dot.className = "dot";
        dot.addEventListener("click", () => {
            currentIndex = i;
            stopSlideshow(); // Stop the slideshow when a dot is clicked
            updateBackground();
        });
        dotContainer.appendChild(dot);
    }
}

document.getElementById("nextBtn").addEventListener("click", function () {
    currentIndex++;
    stopSlideshow(); // Stop the slideshow when next button is clicked
    if (currentIndex >= images.length) {
        currentIndex = 0;
    }
    updateBackground();
});

document.getElementById("prevBtn").addEventListener("click", function () {
    currentIndex--;
    stopSlideshow(); // Stop the slideshow when prev button is clicked
    if (currentIndex < 0) {
        currentIndex = images.length - 1;
    }
    updateBackground();
});

var slideshowInterval; // Declare a variable to store the interval ID

// Function to start the slideshow
function startSlideshow() {
    slideshowInterval = setInterval(() => {
        currentIndex++;
        if (currentIndex >= images.length) {
            currentIndex = 0;
        }
        updateBackground();
    }, 4300); // Change 5000 to the desired interval in milliseconds (e.g., 5000 for 5 seconds)
}

// Function to stop the slideshow
function stopSlideshow() {
    clearInterval(slideshowInterval);
}

// Call startSlideshow function to begin the slideshow
startSlideshow();

generateDots();
updateBackground();